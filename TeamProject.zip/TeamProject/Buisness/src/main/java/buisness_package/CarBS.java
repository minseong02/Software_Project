/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package buisness_package;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.GridLayout;
import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;

/**
 *
 * @author mskim
 */
public class CarBS extends JPanel{
    public CarBS(){
        super(new BorderLayout());
        rentalcar_list();
    }
    
    void rentalcar_list(){
        setLayout(null);
        
        // 이미지를 표시할 JLabel//
        JLabel hotel_image_label = new JLabel();
        ImageIcon hotel_list_Icon = new ImageIcon("car_list.png");
        hotel_image_label.setIcon(hotel_list_Icon);
        hotel_image_label.setBounds(18,1,80,80);
        add(hotel_image_label);
        
        // 상단 패널 //
        JPanel input_panel = new JPanel();
        input_panel.setBorder(new TitledBorder(new LineBorder(Color.gray,1),"입력"));
        input_panel.setLayout(new GridLayout(5,4,10,15));
        
        input_panel.add(new JLabel("비즈니스 넘버"));
        JTextField  Car_BS_num = new JTextField();
        input_panel.add(Car_BS_num);
        
        input_panel.add(new JLabel("자동차 회사"));
        JTextField car_company = new JTextField();
        input_panel.add(car_company);
        
        input_panel.add(new JLabel("렌터카 비용"));
        JPanel car_costPanel = new JPanel();
        car_costPanel.setLayout(new GridLayout(1, 2));
        JTextField car_cost_text = new JTextField();
        car_costPanel.add(car_cost_text);
        car_costPanel.add(new JLabel(" 원"));
        input_panel.add(car_costPanel);
        
        input_panel.add(new JLabel("차종"));
        JPanel vehicle_type_Panel = new JPanel();
        vehicle_type_Panel.setLayout(new GridLayout(1, 2));
        String [] vehicle_type = {"::차종::","경형","준중형","중형","SUV"};
        JComboBox vehicle_type_combo = new JComboBox(vehicle_type);
        input_panel.add(vehicle_type_combo);
        
        
        
        
        
        
        
        
        
        
    }
    
}
